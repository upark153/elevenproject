/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QTableView *tableView;
    QComboBox *comboBox;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *all_people_graph;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(1280, 720);
        tableView = new QTableView(Widget);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(20, 100, 600, 600));
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        comboBox = new QComboBox(Widget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName("comboBox");
        comboBox->setGeometry(QRect(20, 30, 200, 40));
        QFont font;
        font.setPointSize(16);
        comboBox->setFont(font);
        verticalLayoutWidget = new QWidget(Widget);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(650, 100, 601, 601));
        all_people_graph = new QVBoxLayout(verticalLayoutWidget);
        all_people_graph->setObjectName("all_people_graph");
        all_people_graph->setContentsMargins(0, 0, 0, 0);

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("Widget", "\355\205\214\354\235\264\353\270\224 \354\204\240\355\203\235", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("Widget", "\352\264\221\354\202\260\352\265\254 \354\240\204\354\262\264 \354\235\270\352\265\254", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("Widget", "\353\266\200\353\217\231\354\202\260\354\227\205\354\262\264/\354\202\260\354\227\205\353\213\250\354\247\200", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("Widget", "\355\216\270\354\235\230 \354\213\234\354\204\244", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("Widget", "\354\235\214\354\213\235 \354\213\234\354\204\244", nullptr));
        comboBox->setItemText(5, QCoreApplication::translate("Widget", "\355\230\274\355\225\251 \354\213\234\354\204\244", nullptr));

    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
