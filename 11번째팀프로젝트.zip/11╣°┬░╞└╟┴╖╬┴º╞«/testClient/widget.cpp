#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QDataStream>
#include <QList>
#include <QString>
#include <QDebug> //완료



Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget),
      m_socket(new QTcpSocket(this)), //소켓 생성
      m_socketReady(false) //소켓대기 false
{
    ui->setupUi(this);
    m_socket -> connectToHost("localhost", 5050); //소켓 생성

    connect(m_socket,QTcpSocket::readyRead,this,&Widget::readData); // 소켓과 연결
    connect(m_socket,&QTcpSocket::connected, this, &Widget::socketReadey); //소켓과 연결
    connect(m_socket,&QTcpSocket::stateChanged,this,&Widget::stateChanged); //소켓과 연결

    ui->all_people_graph->addWidget(chartView); //ui에 차트넣음
//    chartView->setRenderHint(QPainter::Antialiasing);



}

//소켓 대기
void Widget::socketReadey()
{
    m_socketReady = true;

}

//소켓 상태
void Widget::stateChanged(QAbstractSocket::SocketState socketState)
{
    qDebug() << "소켓상태확인->" <<socketState;
    //QAbstractSocket::ConnectingState->소켓이 연결중인 상태다.
    //QAbstractSocket::UnconnectedState->소켓이 연결되지 않은 상태
    //QAbstractSocket::ConnectedState->연결된상태
}

// 송신
void Widget::on_comboBox_currentTextChanged(const QString &arg1) //콤보박스 선택 할때마다 서버로 콤보텍스트를 보냄.
{
    qDebug()<<"제발돼라!!!!!!!!!";



    if(m_socketReady)
    {
        if (ui->comboBox->currentIndex()== 1)
        {
//            setchart();
            QString c_idx1 = ui->comboBox->currentText();
            QDataStream out(m_socket);
            out << c_idx1;
        }
    }

}


// 수신
void Widget::readData()
{
    QList<QList<QString>> doubl_data_list; //이중리스트 선언
    int h_len;   //행갯수
    int c_len;   //칼럼갯수

    QDataStream in(m_socket);
    in.startTransaction(); // 전체 데이터를 가질 때까지 기다렸다가 한번에 읽고 모든 것을 읽을 수 있게 해준다.

    QString recvString;
    in >> recvString;

    if(!in.commitTransaction())
    {
        return; // wait for more data
    }

    qDebug()<<"받은데이터"<<recvString;

    QStringList data_list = recvString.split(";");
    qDebug() << "data_list:"<< data_list;
    h_len =data_list[0].toInt(); //22
    c_len =data_list[1].toInt(); //5
    data_list.removeAt(0);
    data_list.removeAt(0);
    int list_len = data_list.length();
    int list_count =0;

    for (int i = 0; i < h_len; i++) {
            QList<QString> inner_list;
            for (int j = 0; j < c_len; j++) {
                inner_list.append(data_list[list_count]);
                list_count++;
            }
            doubl_data_list.append(inner_list);
        }

    qDebug() << doubl_data_list;

    setchart();

}

void Widget::setchart()
{

//   QLayoutItem *erase;
//   while ((erase = ui->all_people_graph->takeAt(0))!=0){
//       delete erase->widget();
//       delete erase;
//   }
   chart->removeAllSeries(); //차트 리무브
//   chart->setTitle("");
   axisX->clear();

   QBarSeries *series = new QBarSeries();
   chart->removeAllSeries();
   chart->addSeries(series);
//   chart->legend()->setVisible(true); //범례켜기
   chart->legend()->setAlignment(Qt::AlignBottom); //범례위치
   chart->setTitle("Simple barchart example"); //차트제목
   chart->setAnimationOptions(QChart::SeriesAnimations); //차트애니메이션


    QBarSet *set0 = new QBarSet("Jane");
    QBarSet *set1 = new QBarSet("John");
    QBarSet *set2 = new QBarSet("Axel");
    QBarSet *set3 = new QBarSet("Mary");
    QBarSet *set4 = new QBarSet("Samantha");

    *set0 << 1 ;
    *set1 << 5 << 0 << 0 << 4 << 0 << 7;
    *set2 << 3 << 5 << 8 << 13 << 8 << 5;
    *set3 << 5 << 6 << 7 << 3 << 4 << 5;
    *set4 << 9 << 7 << 5 << 3 << 1 << 2;

    series->append(set0);
    series->append(set1);
    series->append(set2);
    series->append(set3);
    series->append(set4);


    QStringList categories;
    categories << "Jan" << "Feb" << "Mar" << "Apr" << "May" << "Jun";\

    //x축
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);
    //y축
    axisY->setRange(0,15);
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    chartView->update();
    chartView->resize(540,300); //차트창 사이즈 조절




// 차트 새로운 창에서 뜨게하는거
//    QMainWindow *window = new QMainWindow();
//    window->setCentralWidget(chartView);
//    window->resize(600, 300);
//    window->show();

}

Widget::~Widget()
{
    m_socket -> close();
    delete ui;
}

