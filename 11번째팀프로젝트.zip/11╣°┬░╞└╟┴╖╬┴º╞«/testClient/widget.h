#ifndef WIDGET_H
#define WIDGET_H

//#include <QMainWindow>
#include <QWidget>
#include <QTcpSocket>

#include <QChart>
#include <QChartView>
#include <QGraphicsWidget> // 범례 키기 위함
#include <QBarSet>
#include <QBarSeries>
#include <QStringList>
#include <QBarCategoryAxis>
#include <QValueAxis>

#include <QPieSeries>
#include <QPieSlice>


QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();


private slots:
    void socketReadey();
    void stateChanged(QAbstractSocket::SocketState socketState);
    void readData();
    void on_comboBox_currentTextChanged(const QString &arg1);
    void setchart();

private:
    Ui::Widget *ui;
    QTcpSocket *m_socket;
    bool m_socketReady;

    QChart *chart = new QChart();
    QChartView *chartView = new QChartView(chart);
    QBarCategoryAxis *axisX = new QBarCategoryAxis(); //x축(가로)
    QValueAxis *axisY = new QValueAxis(); //y축(세로)
};
#endif // WIDGET_H
