#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QDataStream>
#include <QSql>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QSqlDriver>
#include <QSqlTableModel>
#include <QStringList>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

public slots:
    void gotConnection();
    void readData();

private:
    Ui::Widget *ui;
    QTcpServer m_server;
    QTcpSocket *m_socket;
};
#endif // WIDGET_H
