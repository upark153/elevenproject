#include "widget.h"
#include "ui_widget.h"
#include <QDebug>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);



    setWindowTitle("Server | Data receiver");

    m_socket = nullptr;

    m_server.listen(QHostAddress::LocalHost, 5050);

    connect(&m_server,&QTcpServer::newConnection,this,&Widget::gotConnection);

//    qDebug() << "드라이버" << QSqlDatabase::drivers();
//    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
//    db.setHostName("10.10.21.111"); // IP 또는 DNS Host name
//    db.setDatabaseName("compnay_project2"); // DB명
//    db.setUserName("beom"); // 계정 명
//    db.setPassword("123456789"); // 계정 Password



}

Widget::~Widget()
{
    if (m_socket)
    {
        qDebug() << "Closing socket : " << (m_socket==nullptr);
        m_socket -> close();
        m_socket -> deleteLater();
    }
    m_server.close();
    delete ui;
}

void Widget::gotConnection()
{
    qDebug() << "Server got new connection";
    m_socket = m_server.nextPendingConnection();
    connect(m_socket,QTcpSocket::readyRead,this,&Widget::readData);
}

void Widget::readData()
{
    QDataStream in(m_socket);

    in.startTransaction(); // 전체 데이터를 가질 때까지 기다렸다가 한번에 읽고 모든 것을 읽을 수 있게 해준다.

    QString recvString;
    in >> recvString;

    if(!in.commitTransaction())
    {
        return; // wait for more data
    }



    ui->textEdit->append(recvString);

    if(recvString=="어흥")
    {
        QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
                   db.setHostName("10.10.21.111");
                   db.setDatabaseName("compnay_project2");
                   db.setUserName("beom");
                   db.setPassword("123456789");
                   db.open();


        QSqlQuery query;
        QString qry;
        QList<QString> a;
        QString gogogo;
        QList<QList<QString>> data_list;
        int h_len;  //행 개수
        int c_len;  //열 개수

        query.exec("SELECT count(Dong) from compnay_project2.all_people");    //해당 조회의 행 숫자가 몇개인지 알아내는 쿼리문
        while (query.next()) {
            qDebug() << query.value(0).toInt();
            h_len = query.value(0).toInt();

        }
        query.exec("SELECT COUNT(*) FROM information_schema.columns WHERE table_name='all_people'"); //해당 조회의 칼럼값이 몇개인지 알아내는 쿼리문
        while (query.next()) {
            qDebug() << query.value(0).toInt();
            c_len = query.value(0).toInt();

        }


        query.exec("SELECT * FROM compnay_project2.all_people");  //해당 테이블 조회


                while(query.next())
                    {




                                QList<QString> inner_list;
                                for (int j = 0; j < c_len; j++) {
                                    inner_list.append(query.value(j).toString()); // 1행의 값들을 넣음
                                }
                                data_list.append(inner_list);


//                        qDebug() << query.value(0).toString() << query.value(1).toString() << query.value(2).toString() << query.value(3).toString() << query.value(4).toString();
//                        QString abc;



//                        a.append(query.value(0).toString());
//                        a.append(query.value(1).toString());
//                        a.append(query.value(2).toString());
//                        a.append(query.value(3).toString());
//                        a.append(query.value(4).toString());

                    }


//                QDataStream out(m_socket);
//                out << data_list;
//                qDebug() << data_list[0];



//                for (int i =0;i<a.length(); i++)
//                {
//                    gogogo.append(a[i]);
//                    gogogo.append(";");
//                }
//                QDataStream out(m_socket);
//                out << gogogo;



    }
    else if(recvString == "멍멍")
    {
        QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
                   db.setHostName("10.10.21.111");
                   db.setPort(3306);
                   db.setDatabaseName("compnay_project2");
                   db.setUserName("beom");
                   db.setPassword("123456789");
                   db.open();

        if (db.open())
        {
            qDebug() << "db연결 성공~~";
        }
        else
        {
            qDebug() << "db연결 실패 ㅠㅠ,,";
        }

        QSqlQuery query;
        QString qry;
        QList<QString> a;
        QString gogogo;
        QString h_len;  //행 개수
        QString c_len;  //열 개수

        query.exec("SELECT count(Dong) from compnay_project2.all_people");    //해당 조회의 행 숫자가 몇개인지 알아내는 쿼리문
        while (query.next()) {
            qDebug() << query.value(0).toInt();
            h_len = query.value(0).toString();

        }
        query.exec("SELECT COUNT(*) FROM information_schema.columns WHERE table_name='all_people'"); //해당 조회의 칼럼값이 몇개인지 알아내는 쿼리문
        while (query.next()) {
            qDebug() << query.value(0).toInt();
            c_len = query.value(0).toString();

        }




        qry = "SELECT * FROM compnay_project2.all_people";
        query.exec(qry);

                while(query.next())
                    {


    //                    qDebug() << query.value(0).toString() << query.value(1).toString() << query.value(2).toString() << query.value(3).toString() << query.value(4).toString();

    //                    QString abc;
                        a.append(query.value(0).toString());
                        a.append(query.value(1).toString());
                        a.append(query.value(2).toString());
                        a.append(query.value(3).toString());
                        a.append(query.value(4).toString());

    //                        QList<QString> a;
    //                        a.append(query.value(0));
    //                        a.append(query.value(1));
    //                        a.append(query.value(2));
    //                        a.append(query.value(3));
    //                        a.append(query.value(4));
    //                        QDebug() << a[0]; << "sibal";
                        //검색한 내용... 끝까지 읽어드려 처리하는 부분

                    }

                gogogo.append(h_len);
                gogogo.append(";");
                gogogo.append(c_len);
                gogogo.append(";");

                for (int i =0;i<a.length(); i++)
                {

                    gogogo.append(a[i]);
                    gogogo.append(";");
                }
                QDataStream out(m_socket);
                out << gogogo;
    }
}

