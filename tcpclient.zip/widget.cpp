#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QDataStream>
#include <QList>
#include <QString>
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget),
      m_socket(new QTcpSocket(this)),
      m_socketReady(false)
{
    ui->setupUi(this);
    setWindowTitle("Client | Data Sender");



    m_socket -> connectToHost("localhost", 5050);

    connect(m_socket,QTcpSocket::readyRead,this,&Widget::readData);
    connect(m_socket,&QTcpSocket::connected, this, &Widget::socketReadey);

    connect(m_socket,&QTcpSocket::stateChanged,this,&Widget::stateChanged);

}

Widget::~Widget()
{
    m_socket -> close();
    delete ui;
}

void Widget::socketReadey()
{
    m_socketReady = true;

}

void Widget::stateChanged(QAbstractSocket::SocketState socketState)
{
    qDebug() << socketState;
}


//void Widget::on_lineEdit_textChanged(const QString &newtext)
//{
//    if(m_socketReady)
//    {
//        QDataStream out(m_socket);
//        out << newtext;

//    }
//}


void Widget::on_pushButton_clicked()
{
    if(m_socketReady)
    {
        QString str = ui->lineEdit->text();
        QDataStream out(m_socket);
        out << str;


    }
}

void Widget::readData()
{


    QList<QList<QString>> doubl_data_list; //이중리스트 선언
    int h_len;   //행갯수
    int c_len;   //칼럼갯수

    QDataStream in(m_socket);
    in.startTransaction(); // 전체 데이터를 가질 때까지 기다렸다가 한번에 읽고 모든 것을 읽을 수 있게 해준다.



    QString recvString;
    in >> recvString;

    if(!in.commitTransaction())
    {
        return; // wait for more data
    }



    QStringList data_list = recvString.split(";");
    qDebug() << data_list;
    h_len =data_list[0].toInt();
    c_len =data_list[1].toInt();
    qDebug() << h_len << "zz "<< c_len;
    data_list.removeAt(0);
    data_list.removeAt(0);
    int list_len = data_list.length();
    int list_count =0;



    for (int i = 0; i < h_len; i++) {

            QList<QString> inner_list;
            for (int j = 0; j < c_len; j++) {
                inner_list.append(data_list[list_count]);
                list_count++;
            }
            doubl_data_list.append(inner_list);
        }

    qDebug() << doubl_data_list;
    qDebug() << doubl_data_list[0];
    qDebug() << doubl_data_list[0][0];
//    h_len = recvString[0];
//    c_len = recvString[2];

}
