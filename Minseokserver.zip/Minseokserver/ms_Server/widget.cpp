#include "widget.h"
#include "ui_widget.h"
#include <QDebug>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    setWindowTitle("Server | Data receiver");

    m_socket = nullptr;

    m_server.listen(QHostAddress::LocalHost, 5050);

    connect(&m_server,&QTcpServer::newConnection,this,&Widget::gotConnection);

    dong.append("도산동");
    dong.append("동곡동");
    dong.append("본량동");
    dong.append("비아동");
    dong.append("삼도동");
    dong.append("송정1동");
    dong.append("송정2동");
    dong.append("수완동");
    dong.append("신가동");
    dong.append("신창동");
    dong.append("신흥동");
    dong.append("어룡동");
    dong.append("우산동");
    dong.append("운남동");
    dong.append("월곡1동");
    dong.append("월곡2동");
    dong.append("임곡동");
    dong.append("첨단1동");
    dong.append("첨단2동");
    dong.append("평동");
    dong.append("하남동");
}

Widget::~Widget()
{
    if (m_socket)
    {
        qDebug() << "Closing socket : " << (m_socket==nullptr);
        m_socket -> close();
        m_socket -> deleteLater();
    }
    m_server.close();
    delete ui;
}

void Widget::gotConnection()
{
    qDebug() << "Server got new connection";
    m_socket = m_server.nextPendingConnection();
    connect(m_socket,QTcpSocket::readyRead,this,&Widget::readData);
}

void Widget::readData()
{
    QDataStream in(m_socket);

    in.startTransaction(); // 전체 데이터를 가질 때까지 기다렸다가 한번에 읽고 모든 것을 읽을 수 있게 해준다.

    QString recvString;
    in >> recvString;

    if(!in.commitTransaction())
    {
        return; // wait for more data
    }

    ui->textEdit->append(recvString);

    // 인구
    if(recvString == "광산구 전체 인구")
    {
        QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("10.10.21.111");
        db.setPort(3306);
        db.setDatabaseName("compnay_project2");
        db.setUserName("beom");
        db.setPassword("123456789");
        db.open();

        if (db.open())
        {
            qDebug() << "db연결 성공~~";
        }
        else
        {
            qDebug() << "db연결 실패 ㅠㅠ,,";
        }

        QSqlQuery query;
        QString qry;
        QList<QString> a;
        QString gogogo;
        QString h_len;  // 열 개수
        QString c_len;  // 행 개수

        query.exec("SELECT count(Dong) from compnay_project2.all_people");    //해당 조회의 행 숫자가 몇개인지 알아내는 쿼리문
        while (query.next()) {
            qDebug() << query.value(0).toInt();
            h_len = query.value(0).toString();

        }
        query.exec("SELECT COUNT(*) FROM information_schema.columns WHERE table_name='all_people'"); //해당 조회의 칼럼값이 몇개인지 알아내는 쿼리문
        while (query.next()) {
            qDebug() << query.value(0).toInt();
            c_len = query.value(0).toString();

        }

        qry = "SELECT * FROM compnay_project2.all_people";
        query.exec(qry);

        while(query.next())
            {
                a.append(query.value(0).toString());
                a.append(query.value(1).toString());
                a.append(query.value(2).toString());
                a.append(query.value(3).toString());
                a.append(query.value(4).toString());
            }

        gogogo.append("광산구 전체 인구");
        gogogo.append(";");
        gogogo.append(h_len);
        gogogo.append(";");
        gogogo.append(c_len);
        gogogo.append(";");

        for (int i =0;i<a.length(); i++){
            gogogo.append(a[i]);
            gogogo.append(";");
        }
        QDataStream out(m_socket);
        out << gogogo;
        db.close();
    }

    // 혼합 시설
    else if(recvString == "혼합 시설"){
        QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("10.10.21.111");
        db.setPort(3306);
        db.setDatabaseName("compnay_project2");
        db.setUserName("beom");
        db.setPassword("123456789");
        db.open();

        if (db.open())
        {
            qDebug() << "db연결 성공~~";
        }
        else
        {
            qDebug() << "db연결 실패 ㅠㅠ,,";
        }

        QSqlQuery query;
        QString qry;
        QString gogogo;

        gogogo.append("혼합 시설;22;5");
        gogogo.append(";");
        qry = "SELECT count(*) as welfare, (select count(*) from compnay_project2.medical) as medical, "
              "(select count(*) from compnay_project2.education) as education,"
              "(select count(*) from compnay_project2.apart_offices) as apart_offices FROM compnay_project2.welfare;";
        query.exec(qry);
        query.next();
        gogogo.append("계");
        for(int i = 0; i < 4; i++){
            gogogo.append(";");
            gogogo.append(query.value(i).toString());
        }

        for(int i = 0; i < 21; i++){
            qry = "SELECT count(*) as welfare, (select count(*) from compnay_project2.medical where Dong = '" + dong[i] + "') as medical, "
                "(select count(*) from compnay_project2.education where Dong = '" + dong[i] + "') as education,"
                "(select count(*) from compnay_project2.apart_offices where Serv_dong = '" + dong[i] + "') as apart_offices "
                "FROM compnay_project2.welfare where Dong = '" + dong[i] + "';";
            query.exec(qry);
            query.next();
            gogogo.append(";");
            gogogo.append(dong[i]);
            for(int j = 0; j < 4; j++){
                gogogo.append(";");
                gogogo.append(query.value(j).toString());
            }
        }

        QDataStream out(m_socket);
        qDebug() << gogogo;
        out << gogogo;
        db.close();
    }

    // 그 외 시설
    else{
        QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("10.10.21.111");
        db.setPort(3306);
        db.setDatabaseName("compnay_project2");
        db.setUserName("beom");
        db.setPassword("123456789");
        db.open();

        if (db.open())
        {
            qDebug() << "db연결 성공~~";
        }
        else
        {
            qDebug() << "db연결 실패 ㅠㅠ,,";
        }

        QSqlQuery query;
        QString qry;
        QString gogogo;

        // 상업
        if(recvString == "부동산업체/산업단지"){
            gogogo.append("부동산업체/산업단지;22;2");
            gogogo.append(";");
            qry = "SELECT count(*) from compnay_project2.commerce";
            query.exec(qry);
            query.next();
            gogogo.append("계;");
            gogogo.append(query.value(0).toString());

            for(int i = 0; i < 21; i++){
                gogogo.append(";");
                qry = "SELECT count(*) from compnay_project2.commerce where Dong = '" + dong[i] + "'";
                query.exec(qry);
                query.next();
                gogogo.append(dong[i] + ";");
                gogogo.append(query.value(0).toString());
            }
        }

        // 편의
        else if(recvString == "편의 시설"){
            gogogo.append("편의 시설;22;2");
            gogogo.append(";");
            qry = "SELECT count(*) from compnay_project2.convenience";
            query.exec(qry);
            query.next();
            gogogo.append("계;");
            gogogo.append(query.value(0).toString());

            for(int i = 0; i < 21; i++){
                gogogo.append(";");
                qry = "SELECT count(*) from compnay_project2.convenience where Dong = '" + dong[i] + "'";
                query.exec(qry);
                query.next();
                gogogo.append(dong[i] + ";");
                gogogo.append(query.value(0).toString());
            }
        }

        // 음식
        else if(recvString == "음식 시설"){
            gogogo.append("음식 시설;22;2");
            gogogo.append(";");
            qry = "SELECT count(*) from compnay_project2.restaurant";
            query.exec(qry);
            query.next();
            gogogo.append("계;");
            gogogo.append(query.value(0).toString());

            for(int i = 0; i < 21; i++){
                gogogo.append(";");
                qry = "SELECT count(*) from compnay_project2.restaurant where Dong = '" + dong[i] + "'";
                query.exec(qry);
                query.next();
                gogogo.append(dong[i] + ";");
                gogogo.append(query.value(0).toString());
            }
        }

        // 예외
        else{
            gogogo.append("테이블 선택;0;0");
        }

        QDataStream out(m_socket);
        qDebug() << gogogo;
        out << gogogo;
        db.close();
    }
}
